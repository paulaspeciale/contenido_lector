/* datos.js · Carga los datos desde archivos JSON separados.
   - datos-ideas.json: las 90 ideas base y sus secciones  → window.BT.SECCIONES
   - datos-bingo.json: los retos del Book Bingo           → window.BT.BINGO
   Uso:  BT.cargarIdeas().then(function () { ... });   BT.cargarBingo().then(function (b) { ... });
   Cada función devuelve siempre la misma promesa (el archivo se pide una sola vez) y nunca rechaza:
   si el JSON no carga, deja los datos vacíos y guarda el error en BT.errorDatos.
   Ojo: fetch no funciona abriendo el HTML con doble clic (file://); hace falta un hosting o un servidor local. */
(function () {
  "use strict";
  window.BT = window.BT || {};
  var B = window.BT;
  var memo = {};

  function pedir(url) {
    return fetch(url, { cache: "no-cache" }).then(function (r) {
      if (!r.ok) throw new Error(url + ": HTTP " + r.status);
      return r.json();
    });
  }

  function una(url, alRecibir, vacio) {
    if (!memo[url]) {
      memo[url] = pedir(url).then(alRecibir).catch(function (e) {
        B.errorDatos = e;
        return vacio();
      });
    }
    return memo[url];
  }

  B.cargarIdeas = function () {
    return una("datos-ideas.json", function (d) {
      B.SECCIONES = d && Array.isArray(d.secciones) ? d.secciones : [];
      return B.SECCIONES;
    }, function () { B.SECCIONES = []; return B.SECCIONES; });
  };

  B.cargarBingo = function () {
    return una("datos-bingo.json", function (d) {
      B.BINGO = d && typeof d === "object" && Array.isArray(d.retos) ? d : { retos: [] };
      return B.BINGO;
    }, function () { B.BINGO = { retos: [] }; return B.BINGO; });
  };
})();
